import java.util.Random;

public class Main {

    // 🔹 Contadores nuevos
    static int mergeMoves = 0;
    static int shellMoves = 0;
    static int quickMoves = 0;

    public static void main(String[] args) {

        int[] arr = new int[100];
        Random random = new Random();

        // Llenar arreglo
        for (int i = 0; i < arr.length; i++) {
            arr[i] = random.nextInt(1000);
        }

        System.out.println("===== BURBUJA (4 PASADAS) =====");
        burbuja(arr.clone());

        System.out.println("\n===== INSERCIÓN =====");
        insercion(arr.clone());

        System.out.println("\n===== SELECCIÓN =====");
        seleccion(arr.clone());

        System.out.println("\n===== MERGE SORT =====");
        int[] copiaMerge = arr.clone();
        mergeMoves = 0; // reset contador
        long inicio = System.nanoTime();
        mergeSort(copiaMerge, 0, copiaMerge.length - 1);
        long fin = System.nanoTime();
        double tiempoMerge = (fin - inicio) / 1_000_000.0;
        System.out.println("Moves: " + mergeMoves);
        System.out.println("Tiempo: " + tiempoMerge + " ms");

        System.out.println("\n===== SHELL SORT =====");
        shellSort(arr.clone());

        System.out.println("\n===== QUICK SORT =====");
        int[] copiaQuick = arr.clone();
        quickMoves = 0; // reset contador
        inicio = System.nanoTime();
        quickSort(copiaQuick, 0, copiaQuick.length - 1);
        fin = System.nanoTime();
        double tiempoQuick = (fin - inicio) / 1_000_000.0;
        System.out.println("Moves: " + quickMoves);
        System.out.println("Tiempo: " + tiempoQuick + " ms");
    }

    // ================= BURBUJA (4 PASADAS) =================
    public static void burbuja(int[] arr) {

        long inicio = System.nanoTime();

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }

            System.out.println("Pasada " + (i + 1) + ":");
            for (int num : arr) {
                System.out.print(num + " ");
            }
            System.out.println("\n");
        }

        long fin = System.nanoTime();
        double tiempoMs = (fin - inicio) / 1_000_000.0;
        System.out.println("Tiempo: " + tiempoMs + " ms");
    }

    // ================= INSERCIÓN =================
    public static void insercion(int[] arr) {

        int inserts = 0;
        long inicio = System.nanoTime();

        for (int i = 1; i < arr.length; i++) {
            int clave = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > clave) {
                arr[j + 1] = arr[j];
                j--;
                inserts++;
            }
            arr[j + 1] = clave;
        }

        long fin = System.nanoTime();
        double tiempoMs = (fin - inicio) / 1_000_000.0;

        System.out.println("Inserts: " + inserts);
        System.out.println("Tiempo: " + tiempoMs + " ms");
    }

    // ================= SELECCIÓN =================
    public static void seleccion(int[] arr) {

        int selects = 0;
        long inicio = System.nanoTime();

        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;

            for (int j = i + 1; j < arr.length; j++) {
                selects++;
                if (arr[j] < arr[min]) {
                    min = j;
                }
            }

            int temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
        }

        long fin = System.nanoTime();
        double tiempoMs = (fin - inicio) / 1_000_000.0;

        System.out.println("Selects: " + selects);
        System.out.println("Tiempo: " + tiempoMs + " ms");
    }

    // ================= MERGE SORT =================
    public static void mergeSort(int[] arr, int izquierda, int derecha) {
        if (izquierda < derecha) {
            int medio = (izquierda + derecha) / 2;
            mergeSort(arr, izquierda, medio);
            mergeSort(arr, medio + 1, derecha);
            merge(arr, izquierda, medio, derecha);
        }
    }

    public static void merge(int[] arr, int izquierda, int medio, int derecha) {
        int n1 = medio - izquierda + 1;
        int n2 = derecha - medio;

        int[] L = new int[n1];
        int[] R = new int[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[izquierda + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[medio + 1 + j];

        int i = 0, j = 0, k = izquierda;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j])
                arr[k++] = L[i++];
            else
                arr[k++] = R[j++];
            mergeMoves++; // 🔹 contar movimiento
        }

        while (i < n1) {
            arr[k++] = L[i++];
            mergeMoves++;
        }

        while (j < n2) {
            arr[k++] = R[j++];
            mergeMoves++;
        }
    }

    // ================= SHELL SORT =================
    public static void shellSort(int[] arr) {

        shellMoves = 0; // reset contador
        long inicio = System.nanoTime();

        for (int gap = arr.length / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < arr.length; i++) {
                int temp = arr[i];
                int j = i;
                while (j >= gap && arr[j - gap] > temp) {
                    arr[j] = arr[j - gap];
                    j -= gap;
                    shellMoves++; // 🔹 movimiento
                }
                arr[j] = temp;
                shellMoves++;
            }
        }

        long fin = System.nanoTime();
        double tiempoMs = (fin - inicio) / 1_000_000.0;
        System.out.println("Moves: " + shellMoves);
        System.out.println("Tiempo: " + tiempoMs + " ms");
    }

    // ================= QUICK SORT =================
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    public static int partition(int[] arr, int low, int high) {

        int pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                quickMoves++; // 🔹 contar swap
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        quickMoves++;

        return i + 1;
    }
}

//¿Cuál algoritmo “mueve” más elementos?
//El algoritmo que más interacciones realizó fue Selección con 4950, ya que en cada iteración compara el elemento actual con el resto del arreglo para encontrar el mínimo. Esto genera un mayor número de comparaciones independientemente del orden inicial.
//¿Cuál te pareció más fácil de entender y por qué?
//El algoritmo que me pareció más fácil de entender fue Burbuja, porque su funcionamiento es secuencial y compara elementos consecutivos, permitiendo visualizar claramente cómo los valores mayores se desplazan hacia el final en cada pasada.